# Twitter Alert Bot 🚨

בוט שמנטר ציוצים (באמצעות Apify Actor) ומעביר אותם לטלגרם.

## איך להפעיל?
1. שים משתני סביבה:
   - `APIFY_TOKEN`
   - `TELEGRAM_TOKEN`
   - `TELEGRAM_CHAT_ID`
2. תריץ: `npm install`
3. תריץ: `npm start`

## Deploy on Railway
- פשוט חבר את הריפו ל-Railway → והוא ירוץ אוטומטית.
